Desková hra Reversi
Autoři: 	Václav Kondula (xkondu00)
		Martin Krajňák (xkrajn02)
Desková hra Reversi (Othelo) s grafickým uživatelským
rozhraním využívající knihovnu Swing. Hru je možné
hrát prot AI nebo jinému hráči a také zvolit různou
velikost hrací desky. 
