wget -O black.png --no-check-cert 'https://www.dropbox.com/s/5k3l7qqcw4slu8f/black.png?dl=1' ;
wget -O white.png --no-check-cert 'https://www.dropbox.com/s/c3zpbr0kbsi2htf/white.png?dl=1' ;
wget -O miglayout15-swing.jar --no-check-cert 'https://www.dropbox.com/s/7n3uyq1dhhctr9h/miglayout15-swing.jar?dl=1' ;
wget -O miglayout-src.zip --no-check-cert 'https://www.dropbox.com/s/odbu75zp34b6c23/miglayout-src.zip?dl=1' ;
